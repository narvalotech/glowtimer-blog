#!/usr/bin/env python3

import serial
import sys
import time

# Replace '/dev/ttyACM0' with the serial port your RP2040 is connected to
SERIAL_PORT = '/dev/ttyACM0'

def enter_bootloader_mode(serial_port):
    try:
        # Open the serial port at 1200 baud
        with serial.Serial(serial_port, 1200, rtscts=True, dsrdtr=True) as ser:
            # Wait a moment for the device to reset
            ser.dtr = False
            time.sleep(.1)
            ser.dtr = True
            time.sleep(5)
            print(f"The device on {serial_port} should now be in bootloader mode.")
    except serial.SerialException as e:
        print(f"Failed to open {serial_port}: {e}")
        sys.exit(1)

if __name__ == "__main__":
    enter_bootloader_mode(SERIAL_PORT)
