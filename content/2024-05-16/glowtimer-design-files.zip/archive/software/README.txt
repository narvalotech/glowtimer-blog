# Software for the GlowTimer

There are two implementations:
- MicroPython
- uLisp

uLisp is the original, micropython was made later.

Here is more information on how to get started for both:

http://www.ulisp.com/show?3KN3#raspberry-pi-pico
https://docs.micropython.org/en/latest/rp2/quickref.html

# Usage / interface

The timer powers-on with a default 5 minutes of countdown.
It starts counting down immediately after setting the time.

There is a short beep 1min before end and another one on end.

Power-on the timer:
- press the middle button
or
- connect to a USB power source

Adjust time:
- left button for less time, right for more
