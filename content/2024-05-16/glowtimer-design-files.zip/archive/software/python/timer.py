# Micropython program
# Designed to run on GlowTimer v1
from machine import Pin, PWM
from math import trunc
from neopixel import NeoPixel
import time


PIN_LEFT_BUTTON = 2
PIN_RIGHT_BUTTON = 1
PIN_POWEROFF = 6
PIN_SPEAKER = 5
PIN_LED = 9


def init_io():
    power = Pin(6, Pin.IN)
    left = Pin(2, Pin.IN, Pin.PULL_UP)
    right = Pin(1, Pin.IN, Pin.PULL_UP)

    return {'left': left,
            'right': right,
            'power': power}

def init_led():
    np = Pin(PIN_LED, Pin.OUT)
    leds = NeoPixel(np, 10)

    # Clear the display
    for led in leds:
        led = (0, 0, 0)
    leds.write()

    return leds

def left(p):
    return not p['left'].value()

def right(p):
    return not p['right'].value()

def dim(color):
    return trunc(0.3 * color)

def show_digits(minutes, leds):
    purple = [dim(color) for color in [0xff, 0x69, 0xb4]]

    leds.fill([0, 0, 0])
    for i in range(minutes):
        leds[i] = purple
    leds.write()

# Function to calculate the frequency of a note
def note_frequency(note, octave=0):
    A4_note_number = 9 # C starts at 0
    A4_octave = 4
    A4_frequency = 440
    frequency = A4_frequency * (2 ** ((note + (octave * 12) - (A4_note_number + (A4_octave * 12))) / 12))
    return frequency

# Function to play a tone on a specific pin
def play_tone(pin_number, note_number, octave=0):
    pin = Pin(pin_number)
    pwm = PWM(pin)
    frequency = note_frequency(note_number, octave)
    pwm.freq(int(frequency))
    pwm.duty_u16(32768)  # Set duty cycle to 50% for maximum volume

# Function to stop the tone
def stop_tone(pin_number):
    pin = Pin(pin_number)
    pwm = PWM(pin)
    pwm.deinit()

def play_tune (notes):
    # notes is (tone, octave, on, off)
    for note in notes:
        tone, octave, on, off = note
        play_tone(PIN_SPEAKER,
                  tone,
                  octave)
        time.sleep(on / 1000)
        stop_tone(PIN_SPEAKER)
        time.sleep(off / 1000)

def power_off():
    power = Pin(PIN_POWEROFF, Pin.OUT)
    power.off()

def minute_elapsed(orig):
    diff = time.time() - orig
    return diff >= 60

def main():
    minutes = 5
    pins = init_io()
    leds = init_led()
    lasttime = time.time()
    tone_1min = False
    time_end = False

    show_digits(minutes, leds)

    while True:
        if minutes > 0 and left(pins):
            minutes -= 1
            lasttime = time.time()
            show_digits(minutes, leds)

        if minutes < 10 and right(pins):
            minutes += 1
            lasttime = time.time()
            show_digits(minutes, leds)

        if (minutes > 0 and minute_elapsed(lasttime)):
            minutes -= 1
            lasttime = time.time()
            show_digits(minutes, leds)

        if minutes > 1:
            tone_1min = False
            tone_end = False

        if minutes == 1 and not tone_1min:
            tune = [
                (0, 4, 150, 150),
                (0, 4, 150, 150),
            ]
            play_tune(tune)
            tone_1min = True

        if minutes == 0 and not tone_end:
            tune = [
                (0, 4, 150, 0),
                (7, 4, 150, 0),
                (12, 4, 150, 0),
            ]
            play_tune(tune)
            tone_end = True
            power_off()

        time.sleep(.1)

main()
