# Electronics for the GlowTimer

WARNING:

This archive reflects what I sent to the printed-circuit-board manufacturer.

_IT DOES NOT FUNCTION AS-IS_

The circuit needed some manual re-work steps as outlined below:

## 3V regulator

Doesn't work well enough, voltage drop is too high.
Replaced by H7605-33MR.


## Soft-power-on circuit

1. An unprogrammed microcontroller will result in turning off the power, all the time.
-> disconnect (cut the trace) to POWEROFF for programming and reconnect it after.
-> this rework is not necessary anymore after the power-selection circuit is added

2. POWERON: schematic error, D2 needs to be *after* R14, not before.


## Power-selection circuit

This is a new circuit that I added "manually" to auto-switch between USB and battery power.
-> Needs an additional mosfet, zener and pull-down resistor.


## LEDs

VDD on LED _needs_ to be 5V.
-> switched to VSYS
-> needs a level shifter between microcontroller and LED input

Connector to the LEDs is reversed, classic mistake.
-> solder wires to the right pins instead


# Battery

The battery used is lithium-polymer pouch-cell.
Here is the exact one I used: https://www.aliexpress.com/item/4001035665787.html

The final version (had the kickstarter been funded) would have been LiFePo4 as it is safer.


# Mechanical assembly

Some screws are needed to fasten both PCBs to the case.
I don't have the exact model, as they came from a laptop screw assortment box.
You will have to experiment, the size is around M2.
